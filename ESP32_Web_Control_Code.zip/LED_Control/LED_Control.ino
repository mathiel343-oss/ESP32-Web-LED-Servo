#include <WiFi.h>
#include <WebServer.h>

const char* AP_SSID = "mathayelESP";
const char* AP_PASSWORD = "123456789";
const int LED_PIN = 2;

WebServer server(80);
bool ledState = false;

const char PAGE[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ESP32 LED Control</title>
<style>
body{font-family:Arial;text-align:center;background:#f4f4f4;padding:40px}
.card{max-width:500px;margin:auto;background:white;padding:30px;border-radius:18px}
button{font-size:22px;padding:14px 30px;margin:10px;border:0;border-radius:12px}
.on{background:#28a745;color:white}.off{background:#dc3545;color:white}
#status{font-size:22px;margin:20px}
</style></head>
<body><div class="card"><h1>ESP32 LED Control</h1>
<p id="status">LED: OFF</p>
<button class="on" onclick="setLED(1)">ON</button>
<button class="off" onclick="setLED(0)">OFF</button></div>
<script>
async function setLED(v){await fetch('/led?state='+v);
document.getElementById('status').innerText='LED: '+(v?'ON':'OFF');}
</script></body></html>
)rawliteral";

void handleRoot(){ server.send(200,"text/html; charset=utf-8",PAGE); }

void handleLED(){
  if(!server.hasArg("state")){server.send(400,"text/plain","Missing state");return;}
  int state=server.arg("state").toInt();
  if(state!=0 && state!=1){server.send(400,"text/plain","State must be 0 or 1");return;}
  ledState=(state==1);
  digitalWrite(LED_PIN,ledState?HIGH:LOW);
  server.send(200,"text/plain",ledState?"LED ON":"LED OFF");
}

void setup(){
  Serial.begin(115200);
  pinMode(LED_PIN,OUTPUT);
  digitalWrite(LED_PIN,LOW);
  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID,AP_PASSWORD);
  Serial.println("ESP32 LED Access Point started!");
  Serial.print("Open: http://"); Serial.println(WiFi.softAPIP());
  server.on("/",HTTP_GET,handleRoot);
  server.on("/led",HTTP_GET,handleLED);
  server.begin();
}

void loop(){ server.handleClient(); }
