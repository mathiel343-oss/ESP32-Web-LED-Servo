#include <WiFi.h>
#include <WebServer.h>
#include <ESP32Servo.h>

const char* AP_SSID = "mathayelESP";
const char* AP_PASSWORD = "123456789";
const int SERVO_PIN = 18;

WebServer server(80);
Servo myServo;
int currentAngle=90;

const char PAGE[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="ar" dir="rtl"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ESP32 Servo Control</title>
<style>
body{font-family:Arial;text-align:center;background:#f4f4f4;padding:40px}
.card{max-width:500px;margin:auto;background:white;padding:30px;border-radius:18px}
button{font-size:22px;padding:14px 25px;margin:10px;border:0;border-radius:12px}
input{font-size:20px;width:100px;padding:10px;text-align:center}
#status{font-size:22px;margin:20px}
</style></head>
<body><div class="card"><h1>التحكم في Servo</h1>
<p id="status">الزاوية الحالية: 90°</p>
<button onclick="moveServo(0)">0°</button>
<button onclick="moveServo(45)">45°</button>
<button onclick="moveServo(90)">90°</button>
<button onclick="moveServo(135)">135°</button>
<button onclick="moveServo(180)">180°</button>
<hr><p>أدخل زاوية من 0 إلى 180:</p>
<input id="angle" type="number" min="0" max="180" value="90">
<button onclick="sendAngle()">تحريك</button></div>
<script>
async function moveServo(a){await fetch('/servo?angle='+a);
document.getElementById('status').innerText='الزاوية الحالية: '+a+'°';}
function sendAngle(){let a=Number(document.getElementById('angle').value);
if(a<0||a>180){alert('اكتب زاوية بين 0 و180');return;} moveServo(a);}
</script></body></html>
)rawliteral";

void handleRoot(){ server.send(200,"text/html; charset=utf-8",PAGE); }

void handleServo(){
  if(!server.hasArg("angle")){server.send(400,"text/plain","Missing angle");return;}
  int angle=server.arg("angle").toInt();
  if(angle<0||angle>180){server.send(400,"text/plain","Angle must be 0-180");return;}
  currentAngle=angle;
  myServo.write(currentAngle);
  server.send(200,"text/plain","Servo moved");
}

void setup(){
  Serial.begin(115200);
  myServo.setPeriodHertz(50);
  myServo.attach(SERVO_PIN,500,2400);
  myServo.write(90);

  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID,AP_PASSWORD);
  Serial.println("ESP32 Servo Access Point started!");
  Serial.print("Open: http://"); Serial.println(WiFi.softAPIP());

  server.on("/",HTTP_GET,handleRoot);
  server.on("/servo",HTTP_GET,handleServo);
  server.begin();
}

void loop(){ server.handleClient(); }
